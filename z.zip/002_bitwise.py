from lshaug import *
import cv2 as cv
import numpy as np

ORIGINAL # 0

src = cv.imread('./image.jpg', cv.IMREAD_GRAYSCALE)

# 나중에 json으로 만들 생각임
# 일단 dict로 하자

aug_dict = {
            'original' :
                        {
                            'ch_idx_list' : [0,5],
                            'is_apply' : True
                        },

            'vertical_sharpen' : 
                        {
                            'ch_idx_list': [2,6],
                            'is_apply' : True,
                            'filter' : [[0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0]]
                        },

            'horisontal_sharpen' :
                        {
                            'ch_idx_list' : [3, 1, 4],
                            'is_apply' : True,
                            'filter' : [[0,0,0,0,0],
                                        [0,0,0,0,0],
                                        [1,1,1,1,1],
                                        [0,0,0,0,0],
                                        [0,0,0,0,0]]
                        },

            'vertical_blur' : 
                        {
                            'ch_idx_list': 3,
                            'is_apply' : False,
                            'filter' : [[0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0]]
                        },
            }

# def check_ch_idx_list_correct(aug_dict)

def get_apply_cnt(aug_dict:dict) -> int:
    cnt = 0
    check_ch_list = [] # 함수로 만들지 않고 내부에서 진행
    for aug_value in aug_dict.values() :
        if aug_value['is_apply'] :
            if not isinstance(aug_value['ch_idx_list'], list) : # 여러채널에 넣을 예정
                print(f'ERR - ch_idx_list is not list!!')
                exit()
            else :
                idx_list = aug_value['ch_idx_list']
            
            for idx in idx_list : 
                if not idx in check_ch_list :
                    check_ch_list.append(idx) # v['ch_idx_list']를 넣지 않아도 됨
                    cnt += 1
                else :
                    err_ch_idx_list = idx # v['ch_idx_list']를 넣지 않아도 됨
                    print(f'ERR - ch_idx_list 중복 발견! {err_ch_idx_list}')
                    exit()
                print(check_ch_list)
    return cnt


dst = np.zeros((src.shape[0], src.shape[1], get_apply_cnt(aug_dict)), dtype=src.dtype)

print(dst.shape)

merge_list = [99 for _ in range(dst.shape[-1])]

print(merge_list)
for aug_name, aug_value in aug_dict.items() :
    if aug_value['is_apply'] : # 우선 적용 되는지 부터 확인한다.
        if aug_name == 'original' : # 나중에 상수로 뺄 것임
            for ch_idx in aug_value['ch_idx_list'] : # 이거 분명 재사용 될 것이다.
                this_ch_img = src.copy() # 단순
                merge_list[ch_idx] = this_ch_img
                # print(merge_list, '\n')

        # elif aug_name == 'vertical_sharpen' :
        elif aug_name.__contains__('sharpen') or aug_name.__contains__('blur'): # 일단 통합
            for ch_idx in aug_value['ch_idx_list'] :
                this_ch_img = cv.filter2D(src, -1 , np.array(aug_value['filter'])/9.) # /9처리할 것
                merge_list[ch_idx] = this_ch_img
                # print(merge_list, '\n')


for each_ch in merge_list :
    print(type(each_ch))

merge_img = cv.merge(merge_list)
print(merge_img.shape)

split_list = cv.split(merge_img)


for idx, _ in enumerate(split_list[:-2]):
    three_merge = cv.merge(split_list[idx:idx+3])
    cv.imshow('merge:3', three_merge)
    cv.waitKey()