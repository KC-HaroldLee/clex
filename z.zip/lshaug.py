import cv2 as cv

DUMMY = 0 # 안 나온댔음

ORIGINAL = 1 # 2^0

SHARPEN_VERTICAL = 2 # 2^1
SHARPEN_HORIZONTAL = 4 # 2^2

BLUR_NORMAL = 8 # 2^3

BLUR_VERTICAL = 16 # 2^4
BLUR_HORIZONTAL = 32 # 2^5
 
CLAHE  = 64 # 2^6

ORIGINAL = 128 
ORIGINAL = 256
ORIGINAL = 512


aug_dict = {
  'original' :
                  {
                            'ch_idx_list' : [0,5],
                            'is_apply' : True
                        },

            'vertical_sharpen' : 
                        {
                            'ch_idx_list': [2,6],
                            'is_apply' : True,
                            'filter' : [[0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0]]
                        },

            'horisontal_sharpen' :
                        {
                            'ch_idx_list' : [3, 1, 4],
                            'is_apply' : True,
                            'filter' : [[0,0,0,0,0],
                                        [0,0,0,0,0],
                                        [1,1,1,1,1],
                                        [0,0,0,0,0],
                                        [0,0,0,0,0]]
                        },

            'vertical_blur' : 
                        {
                            'ch_idx_list': 3,
                            'is_apply' : False,
                            'filter' : [[0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0],
                                        [0,0,1,0,0]]
                        },
            }


'vertical_sharpen'

class LshAug :
    def __init__(self) -> None:
        print('init')